#pragma once

class Brick {

	float brickHeight = 16;
	float brickWidth = 32;


};